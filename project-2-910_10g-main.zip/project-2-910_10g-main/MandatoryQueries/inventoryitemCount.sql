/*Showing inventory count by selecting the number of rows*/
SELECT COUNT(*) AS inventory_item_count
FROM inventory;
