/*delete an employee specified by id*/
DELETE FROM employees
WHERE employee_id = 6
;