/*delete a product specified by id*/
DELETE FROM products
WHERE product_id = 11
;