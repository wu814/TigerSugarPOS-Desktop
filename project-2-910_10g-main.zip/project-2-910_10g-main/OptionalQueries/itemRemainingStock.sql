/*Display stock count of a specific item*/
SELECT supply, stock_remaining
FROM inventory
WHERE supply = 'Red Beans';

