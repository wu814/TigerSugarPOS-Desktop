/*Create a new row for employees*/
INSERT INTO employees (employee_id, first_name, last_name, wage, hours_worked, position)
VALUES (DEFAULT, 'new_first', 'new_last', 10.00, 0, 'new_employee');