/*Display the price for a specific Order*/
SELECT drink_name, price
FROM products
WHERE drink_name = 'Classic Brown Sugar Boba Milk Tea';