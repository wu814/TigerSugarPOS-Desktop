/*Create a new row for inventory*/
INSERT INTO inventory (inventory_id, supply, stock_remaining)
VALUES (DEFAULT, 'new_supply', 10000);