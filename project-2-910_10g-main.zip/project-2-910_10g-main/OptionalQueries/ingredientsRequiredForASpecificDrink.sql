/*Display ingredients required for a specific order*/
SELECT drink_name, ingredients
FROM products
WHERE drink_name = 'Classic Brown Sugar Boba Milk Tea';