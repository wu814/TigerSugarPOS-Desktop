/*delete an inventory specified by id*/
DELETE FROM inventory
WHERE inventory_id = 26
;