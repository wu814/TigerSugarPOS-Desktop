/*Display employee that is a specific position*/
SELECT position, first_name, last_name
FROM employees
WHERE position = 'Sales Associate';